import pool from '../config/databaseConfig.js';
